from django.apps import AppConfig

class ParsedDataConfig(AppConfig):
    name = 'parsed_data'
