from django.contrib import admin
from .models import fb_insight

admin.site.register(fb_insight)

# Register your models here.
